package com.demo;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MyJunit {
	MyDateTestRecord mydet;
	public void setup(MyDate d1,MyDate d2,int expectedResult){
		mydet=new MyDateTestRecord(d1,d2,expectedResult);
		
	}
	@Test
	public void test1(){
		 setup(new MyDate(06, 04, 2011),//case1
                 new MyDate(06, 04, 2011),
                 0);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test2(){
		 setup(new MyDate(06, 04, 2011),//case2
                 new MyDate(18, 04, 2011),
                 12);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test3(){
		 setup(new MyDate(06, 04, 2011),//case3
                 new MyDate(18, 05, 2011),
                 42);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test4(){
		 setup(new MyDate(06, 04, 2011),//case4
                 new MyDate(18, 06, 2011),
                 73);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test5(){
		 setup( new MyDate(06, 04, 2011),//case5
                 new MyDate(18, 12, 2011),
                 256);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test6(){
		 setup(new MyDate(06, 04, 2011),//case6
                 new MyDate(18, 12, 2012),
                 622);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test7(){
		 setup( new MyDate(06, 04, 2011),//case7
                 new MyDate(18, 12, 2013),
                 987);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test8(){
		 setup(new MyDate(06, 04, 2011),//case8
                 new MyDate(18, 12, 2113),
                 37511);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test9(){
		 setup(new MyDate(06, 04, 2011),//case9
                 new MyDate(18, 12, 2413),
                 147084);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test10(){
		 setup(new MyDate(06, 04, 2011),//case10
                 new MyDate(18, 12, 2813),
                 293181);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test11(){
		 setup( new MyDate(06, 01, 2011),//case11
                 new MyDate(06, 03, 2011),
                 59);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test12(){
		 setup(new MyDate(06, 01, 2012),//case12
                 new MyDate(06, 03, 2012),
                 60);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test13(){
		 setup(new MyDate(06, 02, 2012),//case13
                 new MyDate(06, 03, 2012),
                 29);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test14(){
		 setup(new MyDate(22, 01, 2012),//case14
                 new MyDate(15, 11, 2012),
                 298);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
	@Test
	public void test15(){
		 setup(new MyDate(6, 2, 2012),//case15
                 new MyDate(6, 12, 2012),
                 304);
		 MyDate startDate=mydet.startDate;
         MyDate endDate=mydet.endDate;
         long expectedResult =mydet.expectedResult;
         long obtainedResult = DateDifferenceProvider.getDateDifference(startDate, endDate);
		 assertEquals(expectedResult, obtainedResult);
	}
		
	
	}


