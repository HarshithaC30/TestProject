package com.demo;

public class App 
{
    public static void main( String[] args ) {
    	try {
    	DateManipulation d1=new DateManipulation();
    	long x=d1.testDateDiff("12/jan/2000","12/jan/2001");
    	System.out.println(x);
    	}catch(Exception e) {
    		e.printStackTrace();
    		
    	}
    }
}

	


