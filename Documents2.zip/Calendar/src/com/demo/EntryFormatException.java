package com.demo;


	public class EntryFormatException extends RuntimeException{
		
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		public String toString() {
			return "please enter the dates in dd/MM/yyyy format";
		}
		public String getMessage() {
			return "please enter the dates in dd/MM/yyyy format";
		}

	}


