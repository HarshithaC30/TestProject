package com.demo;



import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DateManipulation {
	public long testDateDiff(String date1,String date2){
		try {
		Date firstdate=new SimpleDateFormat("dd/MMM/yyyy").parse(date1);
		Date seconddate=new SimpleDateFormat("dd/MMM/yyyy").parse(date2);
		long diffInMillies=0l;
		long diff=0l;
		if(seconddate.getTime() > firstdate.getTime())
		{
	    diffInMillies = Math.abs(seconddate.getTime() - firstdate.getTime());
	    diff=TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		}else {
			diffInMillies = Math.abs(firstdate.getTime() - seconddate.getTime());
		    diff=TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
			
		}
     return diff;
		}catch(Exception e) {
			throw new EntryFormatException();
			
		}
		
	}

}


