package phoneBook;

public class Test {

	public static void main(String[] args) {
		Friends x=new Friends("pavan");
		x.addFriend("x","9876543210");
		x.addFriend("y","9876543210");
		x.addFriend("a","9976543210");
		x.addFriend("b","9976543210");
		
		x.showFriends();
		
		x.modifyNumber("y","1234567890");
		x.modifyNumber("a","1234567890");
		
		System.out.println("after modification\n");
		
		x.showFriends();
		
		
		String find=x.fndSearch("kk");
		if(find!=null) {
			System.out.println("phone number is:  "+find);
		}
		
		else {
			
			System.out.println("friend not found");
		}
		
		
		
		
		
		
		
		

	}

}
